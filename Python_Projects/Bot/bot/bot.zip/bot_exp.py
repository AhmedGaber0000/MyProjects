from bot_lib import bot
from data import *


chat_ids = [
    "5833709924",
    "1771026853",
    "1321802074",
    "966105170",
    "6381290171",
    "1100754823",
    "1713929930"
]

# for chat_id in chat_ids:

#     a = bot.sendMessage(chat_id, "كان هناك خلل بسيط تم اصلاحه\nالرجاء التواصل مع الادمن في حالة تعطل البوت")
#     print(a)


bot.sendMessage(5847346973,'لقد تم اتاحه البوت لك\nنتمني لك تجربة ممتعة')
